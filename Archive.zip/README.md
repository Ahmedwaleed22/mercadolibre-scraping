## Installation

1. run `pip3 install virtualenv`
2. run `virtualenv env`
3. run `env\source\activate`
4. run `pip3 install -r requirements.txt`


## Fetching Products

run `python3 fetch_products.py`

## Updating Inventory

run `python3 update_products.py`