from operations.update import UpdateInventory

def main():
  update_inventory = UpdateInventory()
  update_inventory.update()

if __name__ == '__main__':
  main()